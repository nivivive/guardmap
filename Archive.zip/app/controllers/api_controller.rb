class ApiController < ApplicationController
  # before_filter :oath_required

  respond_to :json, :xml
	def push

	end
end
