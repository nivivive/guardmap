guardmap
========

Google Hack for a Change

6/1/13

To start the local server so geolocation works, `cd` into the guardmap directory.

Then run
`python -m SimpleHTTPServer`
in a terminal window to serve on `http://localhost:8000`.

