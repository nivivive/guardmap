# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Guardmap::Application.config.secret_token = 'bf714e9c8100fbf51721efafcd914e39a373ac68193df11b7fedd3a0706cdd57dd6fd64a1b8e2b92e9f53bd770ddfd9c28134e60b099f99943b56edb1f582268'
